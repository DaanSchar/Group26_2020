READ ME!
PHASE 1-1
______________________________________________________________________________

1. Download the ExampleProgram.java file and the exampleGraph.zip file

2. Locate the file Locations

3. Unzip and extract the graph.txt files from the .zip file

4. Make sure the files are in the same folder as the program

5. Open up the console

6. Compile the program

	--> javac ExampleProgram.java

7. Add the graph you want to read behind the program in the console
	(make sure to add ".txt")

	--> java ExampleProgram exampleGraph_01.txt

8. Gain information on vertices, edges and the chromatic number!
______________________________________________________________________________

Group 26
	Daan---Leo---Felix---Patrick---Dimitrina---Harry