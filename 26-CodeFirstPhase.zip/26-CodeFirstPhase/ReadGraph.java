import java.io.*;
import java.util.*;

		class ColEdge
			{
			int u;
			int v;
			}


public class ReadGraph2
		{

			static int temp = 11;

		public final static boolean DEBUG = false;

		public final static String COMMENT = "//";

		public static void main( String args[] )
			{
			if( args.length < 1 )
				{
				System.out.println("Error! No filename specified.");
				System.exit(0);
				}


			String inputfile = args[0];

			boolean seen[] = null;

			//! n is the number of vertices in the graph
			int n = -1;

			//! m is the number of edges in the graph
			int m = -1;

			//! e will contain the edges of the graph
			ColEdge e[] = null;

			try 	{
			    	FileReader fr = new FileReader(inputfile);
			        BufferedReader br = new BufferedReader(fr);

			        String record = new String();

					//! THe first few lines of the file are allowed to be comments, staring with a // symbol.
					//! These comments are only allowed at the top of the file.

					//! -----------------------------------------
			        while ((record = br.readLine()) != null)
						{
						if( record.startsWith("//") ) continue;
						break; // Saw a line that did not start with a comment -- time to start reading the data in!
						}

					if( record.startsWith("VERTICES = ") )
						{
						n = Integer.parseInt( record.substring(11) );
						if(DEBUG) System.out.println(COMMENT + " Number of vertices = "+n);
						}

					seen = new boolean[n+1];

					record = br.readLine();

					if( record.startsWith("EDGES = ") )
						{
						m = Integer.parseInt( record.substring(8) );
						if(DEBUG) System.out.println(COMMENT + " Expected number of edges = "+m);
						}

					e = new ColEdge[m];

					for( int d=0; d<m; d++)
						{
						if(DEBUG) System.out.println(COMMENT + " Reading edge "+(d+1));
						record = br.readLine();
						String data[] = record.split(" ");
						if( data.length != 2 )
								{
								System.out.println("Error! Malformed edge line: "+record);
								System.exit(0);
								}
						e[d] = new ColEdge();

						e[d].u = Integer.parseInt(data[0]);
						e[d].v = Integer.parseInt(data[1]);

						seen[ e[d].u ] = true;
						seen[ e[d].v ] = true;

						if(DEBUG) System.out.println(COMMENT + " Edge: "+ e[d].u +" "+e[d].v);

						}

					String surplus = br.readLine();
					if( surplus != null )
						{
						if( surplus.length() >= 2 ) if(DEBUG) System.out.println(COMMENT + " Warning: there appeared to be data in your file after the last edge: '"+surplus+"'");
						}

					}
			catch (IOException ex)
				{
		        // catch possible io errors from readLine()
			    System.out.println("Error! Problem reading file "+inputfile);
				System.exit(0);
				}

			for( int x=1; x<=n; x++ )
				{
				if( seen[x] == false )
					{
					if(DEBUG) System.out.println(COMMENT + " Warning: vertex "+x+" didn't appear in any edge : it will be considered a disconnected vertex on its own.");
					}
				}

			//! At this point e[0] will be the first edge, with e[0].u referring to one endpoint and e[0].v to the other
			//! e[1] will be the second edge...
			//! (and so on)
			//! e[m-1] will be the last edge
			//!
			//! there will be n vertices in the graph, numbered 1 to n

			//creates a list of colors to pick from
			int[]  possibleColor = new int[n];
			possibleColor = possibleColor(possibleColor,n);

			//creates a list of colors for each vertex
			int[] colorList = new int[n];

			//creates a list with all adjacent vertices to the vertex for each vertex
			int[][] vertexList = new int[n][n];
			vertexList = createVertexList(e, vertexList);

			int[][] vertexListtoColor = new int[n][n];

			vertexListtoColor = vertexListtoColor(vertexListtoColor, vertexList, colorList, n);

			int[] sortedArray = degreeSort(e);
			//colors the graph
			finalMethod(vertexList, vertexListtoColor, colorList, possibleColor, sortedArray, n);
			finalMethod(vertexList, vertexListtoColor, colorList, possibleColor, sortedArray, n);
			finalMethod(vertexList, vertexListtoColor, colorList, possibleColor, sortedArray, n);




			int maxColor = 0;
			for(int i = 0; i<n;i++)
			{
				if(colorList[i]> maxColor)
				{
					maxColor = colorList[i];
				}
			}

		System.out.println("Chromatic number = " + maxColor);

				//calls maxDegree method
			int [] maxArray = maxDegree(e);
			int maxDegree = maxArray[0];
			int index = maxArray[1];

			//UPPER BOUND calc
			int upperBound = maxDegree + 1;

				//UPPER BOUND print
				System.out.println("This is the upper bound: " + upperBound);

		}

		public static void finalMethod(int[][] vertexList ,int[][] vertexListtoColor, int[] colorList, int[] possibleColor,int[] sortedArray, int n)
		{
			for(int i = 0; i< sortedArray.length; i++)
			{
				for(int j = 0; j < n; j++){
					if(vertexListtoColor[sortedArray[i]-1][j] == colorList[sortedArray[i]-1])
					{
						changeColor(vertexListtoColor, colorList, possibleColor, sortedArray[i],n);
						vertexListtoColor = vertexListtoColor(vertexListtoColor, vertexList, colorList, n);
					}
				}
			}
		}

		//changes the color the the smallest available color
		public static int[] changeColor(int[][]vertexListtoColor, int[] colorList, int[]possibleColor,int targetedVertex, int n)
		{

			int c = 0;

			for(int i = 0; i < n; i++)
			{
				for(int j = 0; j < n; j++)
					{

						if(vertexListtoColor[targetedVertex-1][i] == possibleColor[j])
						{
							c++;
						}
					}
				}
					colorList[targetedVertex-1] = possibleColor[c];
				return colorList;
		}



		public static int [] degreeSort(ColEdge [] e)
		{
			//finding the max value in graph
				int max = Integer.MIN_VALUE;

				for(int i = 0; i < e.length; i++)
				{
					max = Math.max(max, e[i].u);
				}

				for(int i = 0; i < e.length; i++)
				{
					max = Math.max(max, e[i].v);
				}



				//create new array to store the degree of each vertex from 1 - max
				int length = max;
				int [] degree = new int [length];

				//loop through array and count how often a vertex occurs
				//loop from 0 to max
				for(int i = 0; i < max; i ++)
				{
						//loop through new array
						for(int j = 0; j < e.length; j++)
						{
							//check if i is at array[j]
							//if yes countArray[j] + 1
							if(i == e[j].u)
							{
								degree[i] = degree[i] + 1;
							}

							else if(i == e[j].v)
							{
								degree[i] = degree[i];
							}

						}
				}




				//sort degree from max to min

				//get max in degree
				int maxDegree = Integer.MIN_VALUE;

				for(int k = 0; k < degree.length; k++)
				{
					maxDegree = Math.max(max, degree[k]);
				}

				//create degreeSort storing vertices sorted by degree
				int [] degreeSort = new int [length];
				int n = 0;

					//get index of degree sorted from largest to smallest
				for(int m = maxDegree; m >= 0; m--)
				{
							//loop through degree
							for(int l = 0; l < degree.length; l++)
								{
									if(degree[l] == m)
									{
										//store index of degree[l] in degreeSort[i+1]
										degreeSort[n] = l + 1;
										n++;
									}
								}
				}

						return degreeSort;


		}

		//method maxDegree
		public static int [] maxDegree(ColEdge[] e)
		{

	    //finding the max value
	    int max = Integer.MIN_VALUE;

	    for(int i = 0; i < e.length; i++)
	    {
		    max = Math.max(max, e[i].u);
	    }

	    for(int i = 0; i < e.length; i++)
	    {
		    max = Math.max(max, e[i].v);
	    }


        //creating newArray for storing frequencies of values from 0 to max
	    int [] newArray = new int [max + 1];

	    //loop through values of array
	    for(int i = 0; i <= max; i++)
	    {
		    //loop through array
	        for(int j = 0; j < e.length; j++)
	        {
	    	    if(e[j].u == i)
	    	    {
	    		    newArray[i] = newArray[i] + 1;
	    	    }
	        }

	        for(int j = 0; j < e.length; j++)
	        {
	    	    if(e[j].v == i)
	    	    {
	    		    newArray[i] = newArray[i] + 1;
	    	    }
	        }
        }

            //finding max degree in newArray
            int maxDegree = Integer.MIN_VALUE;
            int index = 0;

            for(int k = 0; k < newArray.length; k++)
            {
    	       if(maxDegree < newArray[k])
    	       {
    	       	maxDegree = newArray[k];
    	       	index = k;
    	       }
            }
            int [] maxArray = {maxDegree, index};
			return maxArray;

    }

		//makes a list of all possible colors the algorithm can pick from
		public static int[] possibleColor(int[] possibleColors, int n)
		{
			for(int i = 0; i<n; i++)
			{
				possibleColors[i] = i+1;
			}
			return possibleColors;
		}


		//creates a list for a specific vertex to which vertices this vertex is connected
		public static int[][] createVertex(ColEdge[] e, int[][] vertexList, int targetedVertex)
		{
		int j = 0;

			for(int i=0;i<e.length;i++)
			{
				if(e[i].v == targetedVertex)
				{
					vertexList[targetedVertex-1][j] = e[i].u;
					j++;
				}
				if(e[i].u == targetedVertex)
				{
					vertexList[targetedVertex-1][j] = e[i].v;
					j++;
				}
			}
			return vertexList;
		}

		//full list of all vertices and to which vertices they are connected
		public static int[][] createVertexList(ColEdge[] e, int[][] vertexList)
		{
			for(int i = 0; i<e.length ; i++)
			{
				vertexList = createVertex(e, vertexList, i);
			}
			return vertexList;
		}

		//turns the vertices inside the vertexList to their current color
		public static int[][] vertexListtoColor(int[][] vertexListtoColor, int[][] vertexList, int[] colorList, int n)
		{
			for(int targetedVertex = 0; targetedVertex < colorList.length; targetedVertex++)
			{
				for(int i = 0; i< n; i++)
				{
					if(vertexList[targetedVertex][i] == 0)
					{
						break;
					} else
					vertexListtoColor[targetedVertex][i] = colorList[vertexList[targetedVertex][i]-1];
				}
			}
			return vertexListtoColor;
		}
}
